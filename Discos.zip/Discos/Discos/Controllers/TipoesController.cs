﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Discos;

namespace Discos.Controllers
{
    public class TipoesController : ApiController
    {
        private DiscosEntities db = new DiscosEntities();

        // GET: api/Tipoes
        public IQueryable<Tipo> GetTipoes()
        {
            return db.Tipoes;
        }

        // GET: api/Tipoes/5
        [ResponseType(typeof(Tipo))]
        public IHttpActionResult GetTipo(int id)
        {
            Tipo tipo = db.Tipoes.Find(id);
            if (tipo == null)
            {
                return NotFound();
            }

            return Ok(tipo);
        }

        // PUT: api/Tipoes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTipo(int id, Tipo tipo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tipo.IdTipo)
            {
                return BadRequest();
            }

            db.Entry(tipo).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TipoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Tipoes
        [ResponseType(typeof(Tipo))]
        public IHttpActionResult PostTipo(Tipo tipo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Tipoes.Add(tipo);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (TipoExists(tipo.IdTipo))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = tipo.IdTipo }, tipo);
        }

        // DELETE: api/Tipoes/5
        [ResponseType(typeof(Tipo))]
        public IHttpActionResult DeleteTipo(int id)
        {
            Tipo tipo = db.Tipoes.Find(id);
            if (tipo == null)
            {
                return NotFound();
            }

            db.Tipoes.Remove(tipo);
            db.SaveChanges();

            return Ok(tipo);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TipoExists(int id)
        {
            return db.Tipoes.Count(e => e.IdTipo == id) > 0;
        }
    }
}