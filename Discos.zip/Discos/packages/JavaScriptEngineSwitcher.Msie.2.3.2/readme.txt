﻿

   --------------------------------------------------------------------------------
                    README file for JS Engine Switcher: MSIE v2.3.2

   --------------------------------------------------------------------------------

      Copyright (c) 2013-2017 Andrey Taritsyn - http://www.taritsyn.ru


   ===========
   DESCRIPTION
   ===========
   JavaScriptEngineSwitcher.Msie contains adapter `MsieJsEngine` (wrapper for the
   MSIE JavaScript Engine for .Net (http://github.com/Taritsyn/MsieJavaScriptEngine)).
   For correct working of the MSIE JavaScript Engine it is recommended to install
   Internet Explorer 9 and above on a server.

   =============
   RELEASE NOTES
   =============
   Added support of MSIE JavaScript Engine version 2.1.2.

   =============
   DOCUMENTATION
   =============
   See documentation on GitHub -
   http://github.com/Taritsyn/JavaScriptEngineSwitcher