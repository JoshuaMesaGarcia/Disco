﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Discos;

namespace Discos.Controllers
{
    public class TituloesController : ApiController
    {
        private DiscosEntities db = new DiscosEntities();

        // GET: api/Tituloes
        public IQueryable<Titulo> GetTitulos()
        {
            return db.Titulos;
        }

        // GET: api/Tituloes/5
        [ResponseType(typeof(Titulo))]
        public IHttpActionResult GetTitulo(int id)
        {
            Titulo titulo = db.Titulos.Find(id);
            if (titulo == null)
            {
                return NotFound();
            }

            return Ok(titulo);
        }

        // PUT: api/Tituloes/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutTitulo(int id, Titulo titulo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != titulo.Id_Disco)
            {
                return BadRequest();
            }

            db.Entry(titulo).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TituloExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Tituloes
        [ResponseType(typeof(Titulo))]
        public IHttpActionResult PostTitulo(Titulo titulo)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Titulos.Add(titulo);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (TituloExists(titulo.Id_Disco))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = titulo.Id_Disco }, titulo);
        }

        // DELETE: api/Tituloes/5
        [ResponseType(typeof(Titulo))]
        public IHttpActionResult DeleteTitulo(int id)
        {
            Titulo titulo = db.Titulos.Find(id);
            if (titulo == null)
            {
                return NotFound();
            }

            db.Titulos.Remove(titulo);
            db.SaveChanges();

            return Ok(titulo);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool TituloExists(int id)
        {
            return db.Titulos.Count(e => e.Id_Disco == id) > 0;
        }
    }
}